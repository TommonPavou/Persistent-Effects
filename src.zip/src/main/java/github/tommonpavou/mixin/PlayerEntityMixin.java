package github.tommonpavou.mixin;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Mixin(ServerPlayerEntity.class)
public abstract class PlayerEntityMixin {
	@Unique
	private static final Map<UUID, List<StatusEffectInstance>> mymod_savedEffects = new ConcurrentHashMap<>();

	@Inject(method = "onDeath", at = @At("HEAD"))
	private void onDeath(CallbackInfo ci) {
		ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

		// Salva gli effetti in una mappa statica usando l'UUID del giocatore
		List<StatusEffectInstance> effects = new ArrayList<>();
		for (StatusEffectInstance effect : player.getStatusEffects()) {
			effects.add(new StatusEffectInstance(effect));
		}
		mymod_savedEffects.put(player.getUuid(), effects);
	}

	@Inject(method = "onSpawn", at = @At("TAIL"))
	private void onSpawn(CallbackInfo ci) {
		ServerPlayerEntity player = (ServerPlayerEntity) (Object) this;

		// Recupera e applica gli effetti salvati
		List<StatusEffectInstance> savedEffects = mymod_savedEffects.remove(player.getUuid());
		if (savedEffects != null) {
			for (StatusEffectInstance effect : savedEffects) {
				player.addStatusEffect(new StatusEffectInstance(effect));
			}
		}
	}
}